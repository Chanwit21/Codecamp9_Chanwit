import React,{useEffect, useState} from 'react'
import './App.css';

function App() {
  const [msg, setMsg] = useState("Msg Start");
  const [toggle, setToggle] = useState(false)

  useEffect(() => {
    console.log("No dependency..run every render")
  })

  useEffect(() => {
    console.log("Blank array dependency....")
  }, [])

  useEffect(() => {
    console.log(msg)
  }, [msg])

  const changeMsg = (s) => {
    setMsg(s)
  }

  return (
    <div className="App">
      <h1>Msg : {msg}</h1>
      <input type="text" value={msg} onChange={e=>setMsg(e.target.value)} disabled={toggle} />
      {/* <input type="text" value={msg} onChange={e=>setMsg(e.target.value)} readOnly={toggle} /> */}
      <button onClick={()=>{changeMsg("one")}} disabled={toggle} >one</button>
      <button onClick={()=>{changeMsg("two")}} >two</button>
      <button onClick={()=>{changeMsg("three")}} >three</button>
      <button onClick={()=>{setToggle(prv=>!prv)}} >Toggle</button>
    </div>
  );
}

export default App;
