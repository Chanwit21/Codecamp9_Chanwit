import React from 'react'
import JobItems from './JobItems'

function Lists(props) {
  const {lists, hdlDel} = props
  return (
    <div className="row justify-content-center">
      {lists.map(x=>(
        <JobItems key={x.id} item={x} hdlDel={hdlDel} />
      ))    
      }
    </div>
  )
}

export default Lists
