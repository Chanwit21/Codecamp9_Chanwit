import axios from 'axios';
import React,{useEffect, useState} from 'react'
import './App.css';
import Addform from './components/AddForm';
import Header from './components/Header';
import Lists from './components/Lists';

const url = "http://localhost:8080"

function App() {
  const [lists, setLists] = useState([])
  const [refresh, setRefresh] = useState(false)

  useEffect( ()=> {
    axios.get(`${url}/todo`)
    .then(res => setLists(res.data.todos))
  },[refresh])

  const hdlAdd = async (text) => {
    await axios.post(`${url}/todo`, {name: text, status: false})
    setRefresh(prv=>!prv)
  }

  const hdlDel = async (xid) => {
    await axios.delete(`${url}/todo/${xid}`);
    setRefresh((prev) => !prev);
  }

  return (
    <div className="App container-md my-4 pb-3 border rounded bg-light">
      <Header />
      <Addform hdlAdd={hdlAdd}/>
      <Lists lists={lists} hdlDel={hdlDel}/>
    </div>  
  );
}

export default App;
