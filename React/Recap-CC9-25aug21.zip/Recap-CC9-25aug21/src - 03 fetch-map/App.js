import axios from 'axios';
import React,{useEffect, useState} from 'react'
import './App.css';
import Addform from './components/AddForm';
import Header from './components/Header';
import Lists from './components/Lists';

function App() {
  const [lists, setLists] = useState([])
  const [text, setText] = useState('')

  // useEffect( ()=> {
  //   axios.get('http://localhost:8080/todo')
  //   .then(res => setLists(res.data.todos))
  // },[])

  useEffect( ()=> {
    (async () => {
      let res = await axios.get('http://localhost:8080/todo')
      setLists(res.data.todos)
    })()
  },[])

  // useEffect( ()=> {
  //   const getData = async () => {
  //     let res = await axios.get('http://localhost:8080/todo')
  //     setLists(res.data.todos)
  //   }
  //   getData()
  // },[])

  return (
    <div className="App container-md my-4 pb-3 border rounded bg-light">
      <Header />
      <Addform />
      <Lists lists={lists}/>
    </div>
  );
}

export default App;
