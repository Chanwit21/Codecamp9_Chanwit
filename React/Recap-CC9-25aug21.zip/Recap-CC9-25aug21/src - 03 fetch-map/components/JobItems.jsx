import React from "react";

function JobItems(props) {
  const {item} = props
  return (
    <div className="col-md-8">
      <div className="input-group">
        <input className="form-control" type="text" readOnly value={item.name} />
        <button className="btn btn-outline-secondary">Edit</button>
        <button className="btn btn-outline-secondary">Delete</button>
      </div>
    </div>
  );
}

export default JobItems;
