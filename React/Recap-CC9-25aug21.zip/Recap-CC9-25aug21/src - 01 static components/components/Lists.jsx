import React from 'react'
import JobItems from './JobItems'

function Lists() {
  return (
    <div>
      <JobItems />
      <JobItems />
      <JobItems />
    </div>
  )
}

export default Lists
