import React from 'react'

function JobItems() {
  return (
    <div>
      <input type="text" readOnly value="JOB Item"/>
      <button>Edit</button>
      <button>Delete</button>
    </div>
  )
}

export default JobItems
