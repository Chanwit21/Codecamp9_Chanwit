import React from 'react'

function Addform() {
  return (
    <div>
      <input type="text" />
      <button>Add</button>
    </div>
  )
}

export default Addform
