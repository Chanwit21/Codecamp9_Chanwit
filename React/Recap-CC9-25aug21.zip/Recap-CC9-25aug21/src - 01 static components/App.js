import React,{useState} from 'react'
import './App.css';
import Addform from './components/AddForm';
import Header from './components/Header';
import Lists from './components/Lists';

function App() {
  return (
    <div className="App">
      <Header />
      <Addform />
      <Lists />
    </div>
  );
}

export default App;
