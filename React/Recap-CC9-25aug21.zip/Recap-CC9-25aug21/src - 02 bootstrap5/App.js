import React,{useState} from 'react'
import './App.css';
import Addform from './components/AddForm';
import Header from './components/Header';
import Lists from './components/Lists';

function App() {
  return (
    <div className="App container-md my-4 pb-3 border rounded bg-light">
      <Header />
      <Addform />
      <Lists />
    </div>
  );
}

export default App;
